import org.postgresql.ds.PGSimpleDataSource;

public class BDD {
    //Singleton contenant la connexion à la base de données
    private static BDD instance = null;

    //Constructeur privé
    private BDD() {
        var ds = new PGSimpleDataSource();
        ds.setServerName("iutinfo-sgbd.uphf.fr");
        ds.setDatabaseName("iutinfo-sgbd.uphf.fr");
        ds.setUser("iutinfo60");
        ds.setPassword("X2gZ2K2t");
    }

    //Méthode permettant de récupérer l'instance de la connexion à la base de données
    public static BDD getInstance() {
        if (instance == null) {
            instance = new BDD();
        }
        return instance;
    }
}
