package org.example;

import java.util.Date;

public class Main {

    public static void insertion() {
        Produit chaise = new Produit(1, "chaise", 7.99, 40);
        Produit table = new Produit(2, "table", 24.99, 30);
        Produit lampe = new Produit(3, "lampe", 19.99, 25);
        Produit lit = new Produit(4, "lit", 99.99, 10);
        Produit tableDeChevet = new Produit(5, "table de chevet", 14.99, 35);
        Produit bureau = new Produit(6, "bureau", 49.99, 15);

        Client guilhem = new Client(1, "Guilhem", "Obies");
        Client cyran = new Client(2, "Cyran", "Bavay");
        Client tristan = new Client(3, "Tristan", "Houdain");

        Commande c1 = new Commande(1, new Date(2024, 1, 14), guilhem);
        Commande c2 = new Commande(2, new Date(2024, 1, 24), cyran);
        Commande c3 = new Commande(3, new Date(2024, 1, 17), tristan);

        c1.addProduit(chaise);
        chaise.addCommande(c1);
        c1.addProduit(bureau);
        bureau.addCommande(c1);
        guilhem.addCommande(c1);

        c2.addProduit(table);
        table.addCommande(c2);
        c2.addProduit(lampe);
        lampe.addCommande(c2);
        cyran.addCommande(c2);

        c3.addProduit(lit);
        lit.addCommande(c3);
        c3.addProduit(tableDeChevet);
        tableDeChevet.addCommande(c3);
        tristan.addCommande(c3);
    }

    public static double moyenne(Client cl) {
        double tot = 0.0;
        for (Commande c: cl.getCommandes()) {
            tot += c.calculerTotal();
        }
        return tot / cl.getCommandes().size();
    }

    public static void main(String[] args) {
        insertion();

        c2.calculerTotal;

        moyenne(guilhem);

    }
}
